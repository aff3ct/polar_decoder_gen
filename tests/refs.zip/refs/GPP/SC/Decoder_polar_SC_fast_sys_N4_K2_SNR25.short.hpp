#ifndef DECODER_POLAR_SC_FAST_SYS_N4_K2_SNR25_HPP_
#define DECODER_POLAR_SC_FAST_SYS_N4_K2_SNR25_HPP_

#include <vector>
#include <cassert>

#include "../Decoder_polar_SC_fast_sys.hpp"

namespace aff3ct
{
namespace module
{
static const std::vector<bool> Decoder_polar_SC_fast_sys_fb_4_2_25 = {
1, 1, 0, 0};

template <typename B, typename R, class API_polar>
class Decoder_polar_SC_fast_sys_N4_K2_SNR25 : public Decoder_polar_SC_fast_sys<B, R, API_polar>
{
public:
	Decoder_polar_SC_fast_sys_N4_K2_SNR25(const int& K, const int& N, const int n_frames = 1)
	: Decoder(K, N, n_frames, API_polar::get_n_frames()),
	  Decoder_polar_SC_fast_sys<B, R, API_polar>(K, N, Decoder_polar_SC_fast_sys_fb_4_2_25)
	{
		const std::string name = "Decoder_polar_SC_fast_sys_N4_K2_SNR25";
		this->set_name(name);
		assert(N == 4);
		assert(K == 2);
	}

	virtual ~Decoder_polar_SC_fast_sys_N4_K2_SNR25()
	{
	}

	void _decode()
	{
		using namespace tools;

		auto &l = this->l;
		auto &s = this->s;

		API_polar::template g0 <2>(   l, 0+0, 0+2,      0+4, 2);
		API_polar::template h  <2>(s, l, 4+0,           2+0, 2);
		API_polar::template xo0<2>(s,    0+2,           0+0, 2);
	}
};
}
}
#endif
