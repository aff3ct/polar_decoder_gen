#ifndef DECODER_POLAR_SC_FAST_SYS_N16_K13_SNR40_HPP_
#define DECODER_POLAR_SC_FAST_SYS_N16_K13_SNR40_HPP_

#include <vector>
#include <cassert>

#include "../Decoder_polar_SC_fast_sys.hpp"

namespace aff3ct
{
namespace module
{
static const std::vector<bool> Decoder_polar_SC_fast_sys_fb_16_13_40 = {
1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

template <typename B, typename R, class API_polar>
class Decoder_polar_SC_fast_sys_N16_K13_SNR40 : public Decoder_polar_SC_fast_sys<B, R, API_polar>
{
public:
	Decoder_polar_SC_fast_sys_N16_K13_SNR40(const int& K, const int& N, const int n_frames = 1)
	: Decoder(K, N, n_frames, API_polar::get_n_frames()),
	  Decoder_polar_SC_fast_sys<B, R, API_polar>(K, N, Decoder_polar_SC_fast_sys_fb_16_13_40)
	{
		const std::string name = "Decoder_polar_SC_fast_sys_N16_K13_SNR40";
		this->set_name(name);
		assert(N == 16);
		assert(K == 13);
	}

	virtual ~Decoder_polar_SC_fast_sys_N16_K13_SNR40()
	{
	}

	void _decode()
	{
		using namespace tools;

		auto &l = this->l;
		auto &s = this->s;

		API_polar::template f  <8>(   l,  0+ 0,  0+ 8,         0+16, 8);
		API_polar::template f  <4>(   l, 16+ 0, 16+ 4,        16+ 8, 4);
		API_polar::template rep<4>(s, l, 24+ 0,                0+ 0, 4);
		API_polar::template gr <4>(s, l, 16+ 0, 16+ 4,  0+ 0, 16+ 8, 4);
		API_polar::template h  <4>(s, l, 24+ 0,                4+ 0, 4);
		API_polar::template xo <4>(s,     0+ 0,  0+ 4,         0+ 0, 4);
		API_polar::template g  <8>(s, l,  0+ 0,  0+ 8,  0+ 0,  0+16, 8);
		API_polar::template h  <8>(s, l, 16+ 0,                8+ 0, 8);
		API_polar::template xo <8>(s,     0+ 0,  0+ 8,         0+ 0, 8);
	}
};
}
}
#endif
