#ifndef DECODER_POLAR_SC_FAST_SYS_N2048_K1843_SNR40_HPP_
#define DECODER_POLAR_SC_FAST_SYS_N2048_K1843_SNR40_HPP_

#include <vector>
#include <cassert>

#include "../Decoder_polar_SC_fast_sys.hpp"

namespace aff3ct
{
namespace module
{
static const std::vector<bool> Decoder_polar_SC_fast_sys_fb_2048_1843_40 = {
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

template <typename B, typename R, class API_polar>
class Decoder_polar_SC_fast_sys_N2048_K1843_SNR40 : public Decoder_polar_SC_fast_sys<B, R, API_polar>
{
public:
	Decoder_polar_SC_fast_sys_N2048_K1843_SNR40(const int& K, const int& N, const int n_frames = 1)
	: Decoder(K, N, n_frames, API_polar::get_n_frames()),
	  Decoder_polar_SC_fast_sys<B, R, API_polar>(K, N, Decoder_polar_SC_fast_sys_fb_2048_1843_40)
	{
		const std::string name = "Decoder_polar_SC_fast_sys_N2048_K1843_SNR40";
		this->set_name(name);
		assert(N == 2048);
		assert(K == 1843);
	}

	virtual ~Decoder_polar_SC_fast_sys_N2048_K1843_SNR40()
	{
	}

	void _decode()
	{
		using namespace tools;

		auto &l = this->l;
		auto &s = this->s;

		API_polar::template f  <1024>(   l,    0+   0,    0+1024,               0+2048, 1024);
		API_polar::template f  < 512>(   l, 2048+   0, 2048+ 512,            2048+1024,  512);
		API_polar::template f  < 256>(   l, 3072+   0, 3072+ 256,            3072+ 512,  256);
		API_polar::template f  < 128>(   l, 3584+   0, 3584+ 128,            3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template g0 <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template g0 <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template g0 <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template g0 <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                         60+   0,    4);
		API_polar::template xo0<   4>(s,      56+   4,                         56+   0,    4);
		API_polar::template xo0<   8>(s,      48+   8,                         48+   0,    8);
		API_polar::template xo0<  16>(s,      32+  16,                         32+   0,   16);
		API_polar::template xo0<  32>(s,       0+  32,                          0+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64,    0+   0, 3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template g0 <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template rep<   8>(s, l, 4080+   0,                         80+   0,    8);
		API_polar::template gr <   8>(s, l, 4064+   0, 4064+   8,   80+   0, 4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                         88+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,   88+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                         92+   0,    4);
		API_polar::template xo <   4>(s,      88+   0,   88+   4,              88+   0,    4);
		API_polar::template xo <   8>(s,      80+   0,   80+   8,              80+   0,    8);
		API_polar::template xo0<  16>(s,      64+  16,                         64+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,   64+   0, 3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template rep<   8>(s, l, 4080+   0,                         96+   0,    8);
		API_polar::template gr <   8>(s, l, 4064+   0, 4064+   8,   96+   0, 4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        104+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  104+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                        108+   0,    4);
		API_polar::template xo <   4>(s,     104+   0,  104+   4,             104+   0,    4);
		API_polar::template xo <   8>(s,      96+   0,   96+   8,              96+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,   96+   0, 4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template g0 <   2>(   l, 4088+   0, 4088+   2,            4088+   4,    2);
		API_polar::template h  <   2>(s, l, 4092+   0,                        114+   0,    2);
		API_polar::template xo0<   2>(s,     112+   2,                        112+   0,    2);
		API_polar::template g  <   4>(s, l, 4080+   0, 4080+   4,  112+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                        116+   0,    4);
		API_polar::template xo <   4>(s,     112+   0,  112+   4,             112+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  112+   0, 4064+  16,    8);
		API_polar::template h  <   8>(s, l, 4080+   0,                        120+   0,    8);
		API_polar::template xo <   8>(s,     112+   0,  112+   8,             112+   0,    8);
		API_polar::template xo <  16>(s,      96+   0,   96+  16,              96+   0,   16);
		API_polar::template xo <  32>(s,      64+   0,   64+  32,              64+   0,   32);
		API_polar::template xo <  64>(s,       0+   0,    0+  64,               0+   0,   64);
		API_polar::template g  < 128>(s, l, 3584+   0, 3584+ 128,    0+   0, 3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template rep<  16>(s, l, 4064+   0,                        128+   0,   16);
		API_polar::template gr <  16>(s, l, 4032+   0, 4032+  16,  128+   0, 4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template rep<   8>(s, l, 4080+   0,                        144+   0,    8);
		API_polar::template gr <   8>(s, l, 4064+   0, 4064+   8,  144+   0, 4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        152+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  152+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                        156+   0,    4);
		API_polar::template xo <   4>(s,     152+   0,  152+   4,             152+   0,    4);
		API_polar::template xo <   8>(s,     144+   0,  144+   8,             144+   0,    8);
		API_polar::template xo <  16>(s,     128+   0,  128+  16,             128+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  128+   0, 3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template g0 <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template g0 <   2>(   l, 4088+   0, 4088+   2,            4088+   4,    2);
		API_polar::template h  <   2>(s, l, 4092+   0,                        166+   0,    2);
		API_polar::template xo0<   2>(s,     164+   2,                        164+   0,    2);
		API_polar::template xo0<   4>(s,     160+   4,                        160+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  160+   0, 4064+  16,    8);
		API_polar::template spc<   8>(s, l, 4080+   0,                        168+   0,    8);
		API_polar::template xo <   8>(s,     160+   0,  160+   8,             160+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  160+   0, 4032+  32,   16);
		API_polar::template spc<  16>(s, l, 4064+   0,                        176+   0,   16);
		API_polar::template xo <  16>(s,     160+   0,  160+  16,             160+   0,   16);
		API_polar::template xo <  32>(s,     128+   0,  128+  32,             128+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64,  128+   0, 3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        192+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  192+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        196+   0,    4);
		API_polar::template xo <   4>(s,     192+   0,  192+   4,             192+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  192+   0, 4064+  16,    8);
		API_polar::template spc<   8>(s, l, 4080+   0,                        200+   0,    8);
		API_polar::template xo <   8>(s,     192+   0,  192+   8,             192+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  192+   0, 4032+  32,   16);
		API_polar::template spc<  16>(s, l, 4064+   0,                        208+   0,   16);
		API_polar::template xo <  16>(s,     192+   0,  192+  16,             192+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  192+   0, 3968+  64,   32);
		API_polar::template h  <  32>(s, l, 4032+   0,                        224+   0,   32);
		API_polar::template xo <  32>(s,     192+   0,  192+  32,             192+   0,   32);
		API_polar::template xo <  64>(s,     128+   0,  128+  64,             128+   0,   64);
		API_polar::template xo < 128>(s,       0+   0,    0+ 128,               0+   0,  128);
		API_polar::template g  < 256>(s, l, 3072+   0, 3072+ 256,    0+   0, 3072+ 512,  256);
		API_polar::template f  < 128>(   l, 3584+   0, 3584+ 128,            3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template g0 <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template g0 <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template g0 <   2>(   l, 4088+   0, 4088+   2,            4088+   4,    2);
		API_polar::template h  <   2>(s, l, 4092+   0,                        270+   0,    2);
		API_polar::template xo0<   2>(s,     268+   2,                        268+   0,    2);
		API_polar::template xo0<   4>(s,     264+   4,                        264+   0,    4);
		API_polar::template xo0<   8>(s,     256+   8,                        256+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  256+   0, 4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template g0 <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        276+   0,    4);
		API_polar::template xo0<   4>(s,     272+   4,                        272+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  272+   0, 4064+  16,    8);
		API_polar::template spc<   8>(s, l, 4080+   0,                        280+   0,    8);
		API_polar::template xo <   8>(s,     272+   0,  272+   8,             272+   0,    8);
		API_polar::template xo <  16>(s,     256+   0,  256+  16,             256+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  256+   0, 3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        288+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  288+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        292+   0,    4);
		API_polar::template xo <   4>(s,     288+   0,  288+   4,             288+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  288+   0, 4064+  16,    8);
		API_polar::template spc<   8>(s, l, 4080+   0,                        296+   0,    8);
		API_polar::template xo <   8>(s,     288+   0,  288+   8,             288+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  288+   0, 4032+  32,   16);
		API_polar::template h  <  16>(s, l, 4064+   0,                        304+   0,   16);
		API_polar::template xo <  16>(s,     288+   0,  288+  16,             288+   0,   16);
		API_polar::template xo <  32>(s,     256+   0,  256+  32,             256+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64,  256+   0, 3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        320+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  320+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        324+   0,    4);
		API_polar::template xo <   4>(s,     320+   0,  320+   4,             320+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  320+   0, 4064+  16,    8);
		API_polar::template h  <   8>(s, l, 4080+   0,                        328+   0,    8);
		API_polar::template xo <   8>(s,     320+   0,  320+   8,             320+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  320+   0, 4032+  32,   16);
		API_polar::template h  <  16>(s, l, 4064+   0,                        336+   0,   16);
		API_polar::template xo <  16>(s,     320+   0,  320+  16,             320+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  320+   0, 3968+  64,   32);
		API_polar::template h  <  32>(s, l, 4032+   0,                        352+   0,   32);
		API_polar::template xo <  32>(s,     320+   0,  320+  32,             320+   0,   32);
		API_polar::template xo <  64>(s,     256+   0,  256+  64,             256+   0,   64);
		API_polar::template g  < 128>(s, l, 3584+   0, 3584+ 128,  256+   0, 3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template g0 <   2>(   l, 4088+   0, 4088+   2,            4088+   4,    2);
		API_polar::template h  <   2>(s, l, 4092+   0,                        386+   0,    2);
		API_polar::template xo0<   2>(s,     384+   2,                        384+   0,    2);
		API_polar::template g  <   4>(s, l, 4080+   0, 4080+   4,  384+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                        388+   0,    4);
		API_polar::template xo <   4>(s,     384+   0,  384+   4,             384+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  384+   0, 4064+  16,    8);
		API_polar::template h  <   8>(s, l, 4080+   0,                        392+   0,    8);
		API_polar::template xo <   8>(s,     384+   0,  384+   8,             384+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  384+   0, 4032+  32,   16);
		API_polar::template h  <  16>(s, l, 4064+   0,                        400+   0,   16);
		API_polar::template xo <  16>(s,     384+   0,  384+  16,             384+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  384+   0, 3968+  64,   32);
		API_polar::template h  <  32>(s, l, 4032+   0,                        416+   0,   32);
		API_polar::template xo <  32>(s,     384+   0,  384+  32,             384+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64,  384+   0, 3840+ 128,   64);
		API_polar::template h  <  64>(s, l, 3968+   0,                        448+   0,   64);
		API_polar::template xo <  64>(s,     384+   0,  384+  64,             384+   0,   64);
		API_polar::template xo < 128>(s,     256+   0,  256+ 128,             256+   0,  128);
		API_polar::template xo < 256>(s,       0+   0,    0+ 256,               0+   0,  256);
		API_polar::template g  < 512>(s, l, 2048+   0, 2048+ 512,    0+   0, 2048+1024,  512);
		API_polar::template f  < 256>(   l, 3072+   0, 3072+ 256,            3072+ 512,  256);
		API_polar::template f  < 128>(   l, 3584+   0, 3584+ 128,            3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template rep<   8>(s, l, 4080+   0,                        512+   0,    8);
		API_polar::template gr <   8>(s, l, 4064+   0, 4064+   8,  512+   0, 4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        520+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  520+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        524+   0,    4);
		API_polar::template xo <   4>(s,     520+   0,  520+   4,             520+   0,    4);
		API_polar::template xo <   8>(s,     512+   0,  512+   8,             512+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  512+   0, 4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        528+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  528+   0, 4080+   8,    4);
		API_polar::template spc<   4>(s, l, 4088+   0,                        532+   0,    4);
		API_polar::template xo <   4>(s,     528+   0,  528+   4,             528+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  528+   0, 4064+  16,    8);
		API_polar::template h  <   8>(s, l, 4080+   0,                        536+   0,    8);
		API_polar::template xo <   8>(s,     528+   0,  528+   8,             528+   0,    8);
		API_polar::template xo <  16>(s,     512+   0,  512+  16,             512+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32,  512+   0, 3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                        544+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4,  544+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                        548+   0,    4);
		API_polar::template xo <   4>(s,     544+   0,  544+   4,             544+   0,    4);
		API_polar::template g  <   8>(s, l, 4064+   0, 4064+   8,  544+   0, 4064+  16,    8);
		API_polar::template h  <   8>(s, l, 4080+   0,                        552+   0,    8);
		API_polar::template xo <   8>(s,     544+   0,  544+   8,             544+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16,  544+   0, 4032+  32,   16);
		API_polar::template h  <  16>(s, l, 4064+   0,                        560+   0,   16);
		API_polar::template xo <  16>(s,     544+   0,  544+  16,             544+   0,   16);
		API_polar::template xo <  32>(s,     512+   0,  512+  32,             512+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64,  512+   0, 3840+ 128,   64);
		API_polar::template spc<  64>(s, l, 3968+   0,                        576+   0,   64);
		API_polar::template xo <  64>(s,     512+   0,  512+  64,             512+   0,   64);
		API_polar::template g  < 128>(s, l, 3584+   0, 3584+ 128,  512+   0, 3584+ 256,  128);
		API_polar::template spc< 128>(s, l, 3840+   0,                        640+   0,  128);
		API_polar::template xo < 128>(s,     512+   0,  512+ 128,             512+   0,  128);
		API_polar::template g  < 256>(s, l, 3072+   0, 3072+ 256,  512+   0, 3072+ 512,  256);
		API_polar::template spc< 256>(s, l, 3584+   0,                        768+   0,  256);
		API_polar::template xo < 256>(s,     512+   0,  512+ 256,             512+   0,  256);
		API_polar::template xo < 512>(s,       0+   0,    0+ 512,               0+   0,  512);
		API_polar::template g  <1024>(s, l,    0+   0,    0+1024,    0+   0,    0+2048, 1024);
		API_polar::template f  < 512>(   l, 2048+   0, 2048+ 512,            2048+1024,  512);
		API_polar::template f  < 256>(   l, 3072+   0, 3072+ 256,            3072+ 512,  256);
		API_polar::template f  < 128>(   l, 3584+   0, 3584+ 128,            3584+ 256,  128);
		API_polar::template f  <  64>(   l, 3840+   0, 3840+  64,            3840+ 128,   64);
		API_polar::template f  <  32>(   l, 3968+   0, 3968+  32,            3968+  64,   32);
		API_polar::template f  <  16>(   l, 4032+   0, 4032+  16,            4032+  32,   16);
		API_polar::template f  <   8>(   l, 4064+   0, 4064+   8,            4064+  16,    8);
		API_polar::template rep<   8>(s, l, 4080+   0,                       1024+   0,    8);
		API_polar::template gr <   8>(s, l, 4064+   0, 4064+   8, 1024+   0, 4064+  16,    8);
		API_polar::template f  <   4>(   l, 4080+   0, 4080+   4,            4080+   8,    4);
		API_polar::template rep<   4>(s, l, 4088+   0,                       1032+   0,    4);
		API_polar::template gr <   4>(s, l, 4080+   0, 4080+   4, 1032+   0, 4080+   8,    4);
		API_polar::template h  <   4>(s, l, 4088+   0,                       1036+   0,    4);
		API_polar::template xo <   4>(s,    1032+   0, 1032+   4,            1032+   0,    4);
		API_polar::template xo <   8>(s,    1024+   0, 1024+   8,            1024+   0,    8);
		API_polar::template g  <  16>(s, l, 4032+   0, 4032+  16, 1024+   0, 4032+  32,   16);
		API_polar::template spc<  16>(s, l, 4064+   0,                       1040+   0,   16);
		API_polar::template xo <  16>(s,    1024+   0, 1024+  16,            1024+   0,   16);
		API_polar::template g  <  32>(s, l, 3968+   0, 3968+  32, 1024+   0, 3968+  64,   32);
		API_polar::template spc<  32>(s, l, 4032+   0,                       1056+   0,   32);
		API_polar::template xo <  32>(s,    1024+   0, 1024+  32,            1024+   0,   32);
		API_polar::template g  <  64>(s, l, 3840+   0, 3840+  64, 1024+   0, 3840+ 128,   64);
		API_polar::template spc<  64>(s, l, 3968+   0,                       1088+   0,   64);
		API_polar::template xo <  64>(s,    1024+   0, 1024+  64,            1024+   0,   64);
		API_polar::template g  < 128>(s, l, 3584+   0, 3584+ 128, 1024+   0, 3584+ 256,  128);
		API_polar::template spc< 128>(s, l, 3840+   0,                       1152+   0,  128);
		API_polar::template xo < 128>(s,    1024+   0, 1024+ 128,            1024+   0,  128);
		API_polar::template g  < 256>(s, l, 3072+   0, 3072+ 256, 1024+   0, 3072+ 512,  256);
		API_polar::template h  < 256>(s, l, 3584+   0,                       1280+   0,  256);
		API_polar::template xo < 256>(s,    1024+   0, 1024+ 256,            1024+   0,  256);
		API_polar::template g  < 512>(s, l, 2048+   0, 2048+ 512, 1024+   0, 2048+1024,  512);
		API_polar::template h  < 512>(s, l, 3072+   0,                       1536+   0,  512);
		API_polar::template xo < 512>(s,    1024+   0, 1024+ 512,            1024+   0,  512);
		API_polar::template xo <1024>(s,       0+   0,    0+1024,               0+   0, 1024);
	}
};
}
}
#endif
