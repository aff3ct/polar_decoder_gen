#ifndef DECODER_POLAR_SCL_FAST_SYS_CA_N4_K2_SNR25_HPP_
#define DECODER_POLAR_SCL_FAST_SYS_CA_N4_K2_SNR25_HPP_

#include <vector>
#include <cassert>

#include "../Decoder_polar_SCL_fast_CA_sys.hpp"

namespace aff3ct
{
namespace module
{
static const std::vector<bool> Decoder_polar_SCL_fast_CA_sys_fb_4_2_25 = {
1, 1, 0, 0};

template <typename B, typename R, class API_polar>
class Decoder_polar_SCL_fast_CA_sys_N4_K2_SNR25 : public Decoder_polar_SCL_fast_CA_sys<B, R, API_polar>
{
public:
	Decoder_polar_SCL_fast_CA_sys_N4_K2_SNR25(const int& K, const int& N, const int& L, CRC<B>& crc, const int n_frames = 1)
	: Decoder(K, N, n_frames, API_polar::get_n_frames()),
	  Decoder_polar_SCL_fast_CA_sys<B, R, API_polar>(K, N, L, Decoder_polar_SCL_fast_CA_sys_fb_4_2_25, crc)
	{
		const std::string name = "Decoder_polar_SCL_fast_CA_sys_N4_K2_SNR25";
		this->set_name(name);
		assert(N == 4);
		assert(K == 2);
	}

	virtual ~Decoder_polar_SCL_fast_CA_sys_N4_K2_SNR25()
	{
	}

	void _decode(const R *Y_N)
	{
		using namespace tools;

		auto  y = Y_N;
		auto &l = this->l;
		auto &s = this->s;

		this->template update_paths_r0<1, 2>(0, 0);
		normalize_scl_metrics<R>(this->metrics, this->L);
		for (auto i = 0; i < this->n_active_paths; i++) 
		{
			const auto path  = this->paths[i];
			const auto child = l[this->up_ref_array_idx(path, 2 -1)].data();
			API_polar::template g0<2>(y, y + 2, child, 2);
		}
		this->template update_paths_r1<1, 2>(0, 2);
		normalize_scl_metrics<R>(this->metrics, this->L);
		for (auto i = 0; i < this->n_active_paths; i++) 
		{
			API_polar::template xo0<2>(s[this->paths[i]], 0 + 2, 0, 2);
		}
	}
};
}
}
#endif
